package com.iitism.mofood.model

data class ChildModel (
    val foodItemId:String,
    val foodName:String,
    val foodCost:String
)