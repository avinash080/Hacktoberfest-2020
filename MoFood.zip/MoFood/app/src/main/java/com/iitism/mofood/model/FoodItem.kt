package com.iitism.mofood.model

data class FoodItem (
    val foodId: String,
    val foodName: String,
    val foodCost: String,
    val restaurantId: String
)